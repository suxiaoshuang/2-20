# _*_ coding:utf-8 _*_
from django.contrib import admin

# # Register your models here.
#
# from .models import UserProfile, EmailVerification, Banner
#
#
# class UserProfileAdmin(admin.ModelAdmin):
#     list_display = ['username', 'nick_name', 'birthday', 'gender', 'address', 'mobile', 'users', 'add_time']
#     list_filter = ['username', 'nick_name', 'birthday', 'gender', 'address', 'mobile']
#     search_fields = ['username', 'nick_name', 'birthday', 'gender', 'address', 'mobile']
#
#
# class EmailVerificationAdmin(admin.ModelAdmin):
#     list_display = ['email', 'code', 'send_type', 'send_time']
#     list_filter = ['email', 'code', 'send_type']
#     search_fields = ['email', 'code', 'send_type', 'send_time']
#
#
# class BannerAdmin(admin.ModelAdmin):
#     list_display = ['users', 'banner_url', 'order']
#     list_filter = ['users', 'banner_url', 'order']
#     search_fields = ['users', 'banner_url', 'order']
#
#
# admin.site.register(UserProfile, UserProfileAdmin)
# admin.site.register(EmailVerification, EmailVerificationAdmin)
# admin.site.register(Banner, BannerAdmin)
