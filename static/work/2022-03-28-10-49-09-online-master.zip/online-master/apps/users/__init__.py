# coding=utf-8
default_app_config = "users.apps.UsersConfig"
