# _*_ coding:utf-8 _*_
from django.apps import AppConfig


class CoursesConfig(AppConfig):
    name = 'courses'
    verbose_name = '课程管理'
