# _*_ coding:utf-8 _*_
from django.apps import AppConfig


class OrganizationsConfig(AppConfig):
    name = 'organizations'
    verbose_name = '机构管理'
