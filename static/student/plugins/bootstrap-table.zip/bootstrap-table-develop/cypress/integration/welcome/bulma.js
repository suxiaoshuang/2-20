require('../../common/welcome')('bulma')
