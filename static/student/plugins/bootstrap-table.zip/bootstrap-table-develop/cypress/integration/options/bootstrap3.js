require('../../common/options')('bootstrap3')
